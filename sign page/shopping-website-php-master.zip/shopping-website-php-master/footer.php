<div id="footer">
			<center><p>Copyright Tarun Gehlaut 336/CO/10<br>Shubham Jain 327/CO/10</p></center>
		</div>
	</div>
	<img id="bottom" src="signup/bottom.png" alt="">