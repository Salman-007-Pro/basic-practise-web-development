shopping-website-php
====================

An online shopping website

* User can change shipping address from what she has specified while registration
* Automatic updation of stock values
* Supplier can update stock values

This needs the following to run

Make a new db with the name "shopping"
Import shopping.sql to this db

Username for db is "root" password is empty ie

Requires a registration for initial use
