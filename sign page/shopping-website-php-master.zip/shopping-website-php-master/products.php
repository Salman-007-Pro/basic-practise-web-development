<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Product Category | Croma Store</title>
<link rel="stylesheet" type="text/css" href="signup/view.css" media="all">
</head>
<body id="main_body" >
		<?php include 'header.php'?>
	<div id="product_container"
		<div id="product-menu">
		<ul id="product-nav">
		<center>
		<li><a href="listphones.php"><img src="images/phones.png"/>Phones</a></li>
		<li><a href="listcameras.php"><img src="images/cameras.png"/>Cameras</a></li>
		<li><a href="listspeakers.php"><img src="images/speakers.png"/>Speakers</a></li>
		</center>
		</ul>
		</div>
		<?php include 'footer.php'?>
	</body>
</html>
		