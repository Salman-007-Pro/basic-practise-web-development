# Project-Online-Shopping-Website

An online shopping website for purchase of merchandise.  

Features:
* User side- Add products to cart, Place an order, Request their desired products
* Admin side- Manage Inventory, Manage Users

Tech Stack: HTML, CSS, Bootstrap, JavaScript, PHP, SQL, Apache Server (XAMPP)

&nbsp;  
By,  
Jimit Dholakia  
[LinkedIn](https://in.linkedin.com/in/jimit105 "LinkedIn Profile")  
[GitHub](https://github.com/jimit105 "GitHub Profile")  
