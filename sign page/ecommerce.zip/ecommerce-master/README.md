ecommerce
=========

**Note: This project is no longer being maintained.**

A PHP e-commerce web application.

1. To set this web application, make sure PHP and PHPMyAdmin is installed on your server.
2. Next open PHPMyAdmin, create a database and import the bolt.sql file. This will generate tables in your database on your server.
3. Upload all files on your server except for bolt.sql or bolt-new-phpmyadmin.sql! I have provided two database files for an old and new version of PHPMyAdmin respectively.
4. The admin user which I have made has an email id sjobs@apple.com / admin@admin.com and the password is steve. (Please confirm this in db or create one manually.
5. Open config.php file and add the details of your PHPMyAdmin's id and password to access the database. Now re-upload this file to the server.
6. Once this is done, go to the url of your website and it should be up and running.

Enjoy!

Currently only COD (Cash on Delivery), has been implemented. Working on email delivery on purchase and payment gateway. Stay tuned for the updates.
