<div class="container-fluid"></br>
  <h2><strong> About Quality Bags</strong></h2>
  <h4>Quality Bags is an online destination for bag shopping. We have a wide veriety of bags available in multiple categories.</h4></br>

  <h3> Our Features </h3>
  <ul class="list-group">
  <li class="list-group-item">>> Wide range of bags that you can choose from.</li>
  <li class="list-group-item">>> Categories to suits your needs as well as fast selection.</li>
  <li class="list-group-item">>> Multiple product checkout at a time.</li>
  <li class="list-group-item">>> Instant checkout</li>
  <li class="list-group-item">>> Amazing offers and more...</li>
</ul>
  <a href="index.php?content_page=Bags" class="btn btn-default btn-lg">View our bags </a></br>
</div>

<div class="container-fluid bg-grey">
  <h2>Our Values</h2></br>
  <h4><strong>MISSION:</strong> Our mission is to preovide quality bags at cheap price.</h4>
  <h4><strong>VISION:</strong> Our vision is to develop customer satisfaction and by improving bag qualities and standards.</h4>
</br></br>
</div>
