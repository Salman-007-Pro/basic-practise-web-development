<?php
$host = 'localhost';
$user = 'johns08'; //Your dochyper username
$pass = '07061990'; //Your dochyper password
$name = 'johns08mysql2'; //The database name you want to use
?>
