# QualityBags-Ecommerce-PHP
QualityBags Ecommerce is an e-commerce project for for Bag shopping. It is built on PHP 5.6 as its back-end.
